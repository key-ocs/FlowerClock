import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import javax.imageio.ImageIO;

/**
 * FlowerClockModel クラスはデータとロジックを担当する。
 * 誕生花の画像や、太陽・月の画像を取得する機能を提供する。
 * 
 * @Author:
 */
public class FlowerClockModel extends Object{

    /**
     * 誕生花の画像ファイル名
     */
    public static final String[] FLOWER_IMAGE_FILENAMES = {
        "1_January_Tulip.png",
        "2_February_Anemone.png",
        "3_March_Ranunculus.png",
        "4_April_Gerbera.png",
        "5_May_Peony.png",
        "6_June_Turkish_Bellflower.png",
        "7_July_Sunflower.png",
        "8_August_Anthurium.png",
        "9_September_Dahlia.png",
        "10_October_Carnation.png",
        "11_November_Lily.png",
        "12_December_Rose.png"
    };

    /**
     * 太陽の画像ファイル名
     */
    public static final String SUN_IMAGE_FILENAME = "sun.png";

    /**
     * 月の画像ファイル名
     */
    public static final String MOON_IMAGE_FILENAME = "moon.png";

    /**
     * 現在の時間を取得する。
     * 
     * @return 現在のカレンダーインスタンス
     */
    public Calendar getCurrentTime() {
        return Calendar.getInstance();
    }

    /**
     * 指定された月に対応する花の画像オブジェクトを取得する。
     * 
     * @param month 月（1〜12）
     * @return 花の画像オブジェクト
     */
    public BufferedImage getFlowerImage(int month) {
        try {
            File imageFile = new File(FLOWER_IMAGE_FILENAMES[month - 1]);
            return ImageIO.read(imageFile);
        } catch (IOException e) {
            System.err.println("Error loading flower image for month: " + month);
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 現在の時刻に基づいて太陽または月の画像オブジェクトを取得する。
     * 
     * @param hourOfDay 現在の時刻（24時間制）
     * @return 太陽または月の画像オブジェクト
     */
    public BufferedImage getSunOrMoonImage(int hourOfDay) {
        try {
            String filename = (hourOfDay >= 6 && hourOfDay < 18) ? SUN_IMAGE_FILENAME : MOON_IMAGE_FILENAME;
            File imageFile = new File(filename);
            return ImageIO.read(imageFile);
        } catch (IOException e) {
            System.err.println("Error loading sun or moon image for hour: " + hourOfDay);
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 画像を指定された幅と高さにスケーリングする。
     * 
     * @param originalImage 元の画像
     * @param targetWidth 目標の幅
     * @param targetHeight 目標の高さ
     * @return スケーリングされた画像
     */
    public BufferedImage scaleImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        // アルファチャンネルを考慮してBufferedImageを作成
        BufferedImage scaledImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics g = scaledImage.createGraphics();
        g.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
        g.dispose();
        return scaledImage;
    }
}
