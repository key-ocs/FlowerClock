/**
 * FlowerClockController クラスはモデルとビューを管理する。
 * 
 * @Author: 
 */
public class FlowerClockController extends Object{
    @SuppressWarnings("unused")
    private FlowerClockModel model;
    private FlowerClockView view;

    /**
     * コンストラクタ
     * 
     * @param model FlowerClockModel のインスタンス
     * @param view FlowerClockView のインスタンス
     */
    public FlowerClockController(FlowerClockModel model, FlowerClockView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * 時計の表示を開始する。
     */
    public void startClock() {
        view.createAndShowGUI();
    }
}
