/**
 * Main クラスはアプリケーションのエントリーポイントを提供する。
 * 
 * @Author: 
 */
public class Main extends Object{
    public static void main(String[] args) {
        // モデル、ビュー、コントローラーのインスタンスを作成
        FlowerClockModel model = new FlowerClockModel();
        FlowerClockView view = new FlowerClockView(model);
        FlowerClockController controller = new FlowerClockController(model, view);
        
        // 時計の表示を開始
        controller.startClock();
    }
}
