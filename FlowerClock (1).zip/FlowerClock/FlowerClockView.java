import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

/**
 * FlowerClockView クラスはユーザーインターフェース部分を担当する。
 * 時計の描画を行う。
 * 
 * @Author:
 */
public class FlowerClockView extends Object{

    private FlowerClockModel model;

    /**
     * コンストラクタ
     * 
     * @param model FlowerClockModelのインスタンス
     */
    public FlowerClockView(FlowerClockModel model) {
        this.model = model;
    }

    /**
     * キャンバス部品（ペンや画像など）を用いた時計ウィンドウを表示する。
     */
    public void createAndShowGUI() {
        
        // ウィンドウの準備
        JFrame mainFrame = new JFrame("FlowerClock");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(600, 600);
        Canvas canvas = new Canvas() {
            public void paint(Graphics graphics) {
                drawClock(graphics);
            }
        };
        mainFrame.add(canvas);
        
        // ウィンドウの表示
        mainFrame.setVisible(true);

        // 時刻更新処理の定義
        TimerTask timerTask = new TimerTask() {
            public void run() {
                canvas.repaint();
            }
        };

        // 時刻更新を１秒ごとに実行
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(timerTask, 0, 1000);   
    }

    /**
     * 時計を描画する。
     * 
     * @param graphics 描画のためのオブジェクト
     */
    public void drawClock(Graphics graphics) {
        Calendar calendar = model.getCurrentTime();
        int hour = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);

        // 午前0時を12時として扱い、12月の花を表示
        if (hour == 0) {
            hour = 12;
        }

        // 時に基づく花の画像を描画（1時なら1月の花、2時なら2月の花、...）
        BufferedImage flowerImage = model.getFlowerImage(hour);
        if (flowerImage != null) {
            drawFlowerImage(graphics, flowerImage, minute);
        } else {
            System.err.println("Flower image is null for hour: " + hour);
        }

        // 太陽または月の画像を描画
        BufferedImage sunOrMoonImage = model.getSunOrMoonImage(calendar.get(Calendar.HOUR_OF_DAY));
        if (sunOrMoonImage != null) {
            // 画像を特定のサイズにスケーリング（例えば、150x150ピクセル）
            int targetSize = 150;
            BufferedImage scaledImage = model.scaleImage(sunOrMoonImage, targetSize, targetSize);

            // 右上に表示
            graphics.drawImage(scaledImage, 600 - targetSize - 10, 10, null); // 10ピクセルの余白を追加
        } else {
            System.err.println("Sun or moon image is null for hour: " + calendar.get(Calendar.HOUR_OF_DAY));
        }
    }

    /**
     * 花の画像を描画する。
     * 
     * @param graphics 描画のためのオブジェクト
     * @param flowerImage 花の画像
     * @param minute 現在の分
     */
    public void drawFlowerImage(Graphics graphics, BufferedImage flowerImage, int minute) {
        // 画像をキャンバスに収まるようにスケーリング
        int canvasWidth = 600;
        int canvasHeight = 600;
        double scale = Math.min((canvasWidth - 40) / (double) flowerImage.getWidth(), (canvasHeight - 40) / (double) flowerImage.getHeight());
        int scaledWidth = (int) (flowerImage.getWidth() * scale);
        int scaledHeight = (int) (flowerImage.getHeight() * scale);
        BufferedImage scaledFlowerImage = model.scaleImage(flowerImage, scaledWidth, scaledHeight);

        // 画像の中心座標（回転軸となる座標）を算出する
        double anchorX = scaledFlowerImage.getWidth() / 2.0;
        double anchorY = scaledFlowerImage.getHeight() / 2.0;
        
        // 回転角度を算出する（度→ラジアン）
        double rotateDegree = minute / 60.0 * 360.0;
        double rotateRadian = Math.toRadians(rotateDegree);

        // 必要な角度（ラジアン）だけ右回転させる
        AffineTransform transform = AffineTransform.getRotateInstance(rotateRadian, anchorX, anchorY);
        AffineTransformOp transformOp = new AffineTransformOp(transform, AffineTransformOp.TYPE_BICUBIC);

        // 中央に配置
        int imageX = (canvasWidth - scaledFlowerImage.getWidth()) / 2;
        int imageY = (canvasHeight - scaledFlowerImage.getHeight()) / 2;

        graphics.drawImage(transformOp.filter(scaledFlowerImage, null), imageX, imageY, null);
    }
}
